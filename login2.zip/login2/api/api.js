

    $("#stop").click(function getType()
{  

if (inputid==null){
                alert ("请输入编号");
		}else{
	$.ajax({
            type: "GET",        //type：(string)请求方式，POST或GET    
		    cache: false,
		    async: true,   //是否异步    
            dataType: "json",    //dataType：(string)预期返回的数据类型。xml,html,json,text等
            url: "http://wx.peoplevip.cn/api/123.php?type=1",  //url：(string)发送请求的地址，可以是服务器页面也可以是WebService动作。
             success: function (msge) {
                  console.log(msge);
				  mm =msge.ResultObj["0"].DeviceID;
				   console.log(mm);
				   if(mm==inputid)
				   {
					   setType(1);
					   window.location.href='./lijitingche2.html';
				   }
				   else{
				   alert ("请确认车辆识别号是否正确");
				   }
				   
               }
			   
           });}
	 
	
});
function setType(status)
{
  /*********
    status传参，1开，0关

  ***********/

    var url = "http://wx.peoplevip.cn/api/123.php?type=0&status="+status;
  $.ajax({
  
        type: "GET",        //type：(string)请求方式，POST或GET    
        cache: false,
        async: true,   //是否异步    
            dataType: "json",    //dataType：(string)预期返回的数据类型。xml,html,json,text等
            url: url,  //url：(string)发送请求的地址，可以是服务器页面也可以是WebService动作。
             success: function (msge) {
                   console.log(msge);
				   console.log(msge.Status);
				   if(msge.Status==1)
				   {alert ("该车位已经被预定");
				   }else{
				   alert ("车锁正在被打开");
				   }

               }
           });
 
}

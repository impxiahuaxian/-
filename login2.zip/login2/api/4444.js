// JavaScript Document

function yudingtingche(data){


//alert (hh);
}
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
/************************
  余额显示API 
  参数：user 用户名

**************************/
$ok = mysqli_connect("localhost","root","root");	//连接数据库
$nn = mysqli_select_db($ok,"test");	//选择数据库
mysqli_query($ok,"set names 'utf8'");	//设定字符集
$sql = "select username from username where username = '$_COOKIE[name1]'";	 //SQL语句
//select 列名称 from 表名称
$result = mysqli_query($ok,$sql);	//执行SQL语句
if($result){
	$num = mysqli_num_rows($result);	//统计执行结果影响的行数
	if($num)	//如果已经存在该用户
	{	
		$sqlby = "select money from username where username = $_COOKIE[name1]";	//SQL语句
		//select 列名称 from 表名称
		$resultby = mysqli_query($ok,$sqlby);	//执行SQL语句
		while($row = mysqli_fetch_row($resultby)){
			echo $row[0];
		}
	}else{
		echo "用户不存在";
	}
}else{
	echo "错误";
}
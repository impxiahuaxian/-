<?php
    if($_COOKIE["user1"]==1)
	{
	include("index.html");
	}else{
	include("denglu.html");
	}
	?>
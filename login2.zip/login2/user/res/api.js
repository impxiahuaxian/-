/*****************************************************************
 jQuery Ajax封装通用类  (linjq)
 *****************************************************************/
    jQuery.axpost=function (urlid,data,successfn) {
        data = (data==null || data=="" || typeof(data)=="undefined")? {"date": new Date().getTime()} : data;
        $.ajax({
            type:'POST',
            data: JSON.stringify(data),
            url: 'http://dudu2.iot.mk:9527/v2/'+urlid+'',
            dataType: "json",
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            success: function(d){
                successfn(d);
            }
        });
    };
    //获取周边停车场
     Ajaxpark = function (data) {
        var urlid='parking/parkinglotinfo';
        return $.axpost(urlid,data,function (data) {
            if (data.errCode===1000){
                indexConcent.markersdom(data.result);
            }
        })
    };
    //私人停车场
    private_park = function (data) {
        var urlid='parking/berth/range';
        return $.axpost(urlid,data,function (data) {
            if (data.errCode===1000){
                    indexConcent.markersdom(data.result);
            }
        })
    };
    //订单
    OrderAjax = function (data) {
        var urlid='order/get';
        console.log(data);
        return $.axpost(urlid,data,function (data) {
            if (data.errCode===1000){
                indexConcent.orderList(data.result);
            }
        })
    };
    //获得微信授权
    myImg = function (data) {
        var urlid='scan/power';
        console.log(data);
        return $.axpost(urlid,data,function (data) {
            if (data.errCode===1000){
                console.log(data);
            }
        })
    };
    //获取车位锁信息
    berthinfo = function (data) {
        var urlid='parking/berthinfo';
        console.log(data);
        return $.axpost(urlid,data,function (data) {
            if (data.errCode===1000){
                console.log(data.result)
            }
        })
    };
    //获取车位信息

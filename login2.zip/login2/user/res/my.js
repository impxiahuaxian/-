(function () {
    //判断当前手机的系统
    window.onload = function () {
        var u = navigator.userAgent;
        if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {//安卓手机
            $("#upPortrait").find("input[type='file']").attr("capture","camera");
        } else if (u.indexOf('iPhone') > -1) {//ios手机
            $("#upPortrait").find("input[type='file']").removeAttr("capture");
        } else if (u.indexOf('Windows Phone') > -1) {
            $("#upPortrait").find("input[type='file']").attr("capture","camera");
        }
    };
//全局变量
    var subscribe = $(".subscribe"),
        order = $(".order"),
        my = $(".my");
    var phone=Util.StorageGetter("phone");
    var phoneName=$("#phoneName");
    var My_modle;
    var loading_All=$(".loading_All"),
        loading_text=$(".loading_text");

    function my_main() {
        My_modle=my_modle();
        my_event();

    }
    function my_modle() {
        var request={url:"http://dudu2.iot.mk/demo/my.html"};

        myImg(request);

        var Img_modle=function (file) {
            if (!file.files || !file.files[0]) {
                return;
            }
            var img = new FormData($("#upPortrait")[0]);
            console.log(img);
            $.ajax({
                url: 'http://139.219.191.138:9527/v2/image/berth/upload',
                type: 'POST',
                dataType: "json",
                data: img,
                processData: false,    //data值是FormData对象，不需要对数据做处理
                contentType: false,    //因为是由<form>表单构造的FormData对象，且已经声明了属性enctype="multipart/form-data"，所以这里设置为false。
                xhrFields:{
                    withCredentials: true
                },
                crossDomain: true,
                success: function (response) {
                    console.log(response);
                    if (response.errCode===1000){
                        loading_text.text("上传成功");
                        loading_All.hide();
                        Util.StorageSetter("uploadImgPath", response.result);
                        $(".my-portrait").attr("src", "http://dudu2.iot.mk:9527/v2/image/"+response.result);
                        $(".my-portrait").css({"top": 0, "left": 0});
                    }else {
                        loading_text.text(response.result);
                        loading_All.click(function () {
                            loading_All.hide();
                        })
                    }
                }
            });
        };
        return{
             Img_modle:Img_modle,
        }
    }
    function my_event() {
        phoneName.text(phone);
        $("#my-portrait").change(function () {
            loading_All.show();
            loading_text.text("我正在帮您上传美美的头像。。。");
            My_modle.Img_modle(this);
            if($(".my-portrait").attr("src")){
                $(".my-portrait").css({"top": 0, "left": 0});
                $(".portrait-btn").css("color", "transparent");}
        });
        if (Util.StorageGetter("uploadImgPath")){
            var objArr=Util.StorageGetter("uploadImgPath");
            $(".my-portrait").attr("src", "http://dudu2.iot.mk:9527/v2/image/"+objArr);
            $(".my-portrait").css({"top": 0, "left": 0});
        }
        $(".footer").on("click", "a", function () {
            if ($(this).hasClass("subscribe")) {
                $(this).addClass("subscribe1 a");
                order.removeClass("order1 a");
                my.removeClass("my1 a");
                window.location.href = "../index.html";
            } else if ($(this).hasClass("order")) {
                $(this).addClass("order1 a");
                my.removeClass("my1 a");
                subscribe.removeClass("subscribe1 a");
                window.location.href = "my_orderlist.html";
            } else if ($(this).hasClass("my")) {
                $(this).addClass("my1 a");
                order.removeClass("order1 a");
                subscribe.removeClass("subscribe1 a");
                window.location.href = "my.html";
            }
        });
    }
    my_main();
})();
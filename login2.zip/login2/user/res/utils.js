//处理缓存数据
    var Util = (function(){
        var StorageGetter = function(key){
            return JSON.parse(localStorage.getItem(key));
        };
        var StorageSetter = function(key,val){
            var strArr = JSON.stringify(val);
            return localStorage.setItem(key,strArr);
        };
        return {
            StorageGetter:StorageGetter,
            StorageSetter:StorageSetter
        };
    })();

(function () {
    var Util = (function(){
        var StorageGetter = function(key){
            return JSON.parse(localStorage.getItem(key));
        };
        var StorageSetter = function(key,val){
            var strArr = JSON.stringify(val);
            return localStorage.setItem(key,strArr);
        };
        return {
            StorageGetter:StorageGetter,
            StorageSetter:StorageSetter
        }
    })();
    function walletmain() {
        walletmodle()
    }
    function walletmodle() {
        var url = "./balance.php?id=00001";
        $.ajax({
            type:'get',
            url: url,
            dataType: 'json',
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            success: function (response) {
                console.log(response);
                    //var result=response.result;
                    //console.log(result);
                    //var Dubean=result.Dubean/100;
                    $(".wallet_money").text(response);
            }
        });
    }
    walletmain();
})();
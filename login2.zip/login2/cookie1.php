<?php
 echo $_COOKIE["user1"];
 echo $_COOKIE["name1"];
 echo $_COOKIE["pwd1"];
 echo $_COOKIE["money"];

	?>

<?php
error_reporting(0);
 //echo ($m);
 $o = $_POST["chongzhi"];
 //echo ($_POST["chongzhi"]);
if($a = "user1=1")
{$con = mysql_connect("localhost","root","root");//连接数据路

$nn = mysql_select_db("test", $con);
$sql1 = mysql_query("SELECT money FROM username WHERE username=$_COOKIE[name1]");
$datarow = mysql_num_rows($sql1); //长度
            //循环遍历出数据表中的数据
$sql_arr = mysql_fetch_assoc($sql1);
$money = $sql_arr['money'];
$p = $o+$money;
$sql=" UPDATE username SET money=$p WHERE username=$_COOKIE[name1]";

if (!mysql_query($sql,$con))
 {
  die('Error: ' . mysql_error());
 
  }
echo "成功充值，正在跳转.....";
echo "<script>window.location.href='shouye.html'</script>";
mysql_close($con);}else{
echo "请先登录";
header("location:index.html");
}
?>

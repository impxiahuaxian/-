<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
  
<script type="text/javascript" src="js/js.js"></script>
</head>
<body>
<?php
    
	include("md5.php");
	if(isset($_POST["submit"]))
	{    
		$user = $_POST["name"];
		$user = inject_check($user);  //预防注入
		$psw = $_POST["pwd"];
		setcookie("name1",$_POST["name"]);
		setcookie("pwd1",$_POST["pwd"]);
		if($user == "" || $psw == "")
		{
			echo "<script>alert('请输入用户名或密码！'); history.go(-1);</script>";
		}
		else
		{
			
			mysql_connect("localhost","root","root");
			mysql_select_db("test");
			mysql_query("set names 'utf8'");
			$sql = "select username,password from username where username = '$_POST[name]' and password = '$_POST[pwd]'";
			$result = mysql_query($sql);
			if($result)
		   {
		   $row = mysql_fetch_array($result);	//将数据以索引方式储存在数组中
		    echo "欢迎回来";
			setcookie("user1","1");
            echo "<script>window.location.href='shouye.html'</script>";
		   }else{
                   echo "<script>alert('用户名或密码不正确！');</script>";
                    }
			}
        }
?>
</body>
</html>
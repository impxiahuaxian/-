<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />  
</head>
<body>
<?php
	include("md5.php");
	//当要 判断一个变量是否已经声明的时候 可以使用 isset 函数 
	//当要 判断一个变量是否已经赋予数据且不为空 可以用 empty 函数 
	//当要 判断 一个变量 存在且不为空 先isset 函数 再用 empty 函数
	if(isset($_POST["Submit"]))
	{   
	     
		$user = $_POST["username"];
		$user = inject_check($user);  //预防注入
		$psw = $_POST["password"];
		$psw_confirm = $_POST["pass2"];
		if($user == "" || $psw == "" || $psw_confirm == "")
		{
			echo "<script>alert('请确认信息完整性！'); history.go(-1);</script>";
		}
		else
		{
			if($psw == $psw_confirm)
			{
				$ok = mysql_connect("localhost","root","root");	//连接数据库
				$nn = mysql_select_db("test",$ok);	//选择数据库
				mysql_query("set names 'gdk'");	//设定字符集
				$sql = "select username from data where username = '$_POST[username]'";	//SQL语句
				//select 列名称 from 表名称
				$result = mysql_query($sql);	//执行SQL语句
				$num = mysql_num_rows($result);	//统计执行结果影响的行数
				if($nn)	//如果已经存在该用户
				{
				      
					echo "<script> console.log(".$_POST[username].");</script>";
					
				}
				if($num)	//如果已经存在该用户
				{
					echo "<script>alert('用户名已存在'); history.go(-1);</script>";
				}
				else	//不存在当前注册用户名称
				{
					
					$sql_insert = "INSERT INTO username(username,password,email)
                        VALUES
                         ('$_POST[username]','$_POST[password]','$_POST[email]')";
					$res_insert = mysql_query($sql_insert,$ok);
					if($res_insert)
					{
						echo "<script>alert('注册成功！');self.location='index.html';</script>";
					}
					else
					{
						echo "<script>alert('系统繁忙，请稍候！'); history.go(-1);</script>";
					}
				}
			}
			else
			{
				echo "<script>alert('密码不一致！'); history.go(-1);</script>";
			}
		}
	}
	else
	{
		echo "<script>alert('提交未成功！');self.location='zhuce.php';</script>";
	}
?>
</body>
</html>
<?php
error_reporting(E_ALL); 
$ch = curl_init();
//$cookie = '';
$header[]= 'lang:zh';
$host ='mwx.mobike.com';
$header[]= 'eption:bb15c';
$header[]= 'open_src:list';
$header[]= 'Mozilla/5.0 (iPhone;www.zh30.com; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Mobile/14F89 MicroMessenger/6.5.12 NetType/WIFI Language/zh_CN';
$header[]= 'Host: '.$host;
$header[]= 'time:1500887680';
$header[]= 'Referer:https://servicewechat.com/wxxxxxxxx/70/page-frame.html';
//$header[]= 'Cookie: '.$cookie;
$url = 'https://mwx.mobike.com/mobike-api/rent/nearbyBikesInfo.do';
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  // 从证书中检查SSL加密算法是否
curl_setopt($ch, CURLOPT_URL,$url);//抓取指定网页
curl_setopt($ch,CURLOPT_HTTPHEADER,$header); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ; // 获取数据返回   
curl_setopt($ch,CURLOPT_POST,1);
$post_date = array(
	"longitude" => $_GET['x'],
	"latitude" => $_GET['y'],
	"citycode" => "0532"
	);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post_date);
echo $output = curl_exec($ch) ; 
curl_close($ch);
?>
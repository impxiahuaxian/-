<?php
//用哪个就将函数名命名为ahash
//一级加密
function bhash($a){
$salt="zhijian123"; //定义一个salt值
$b=$a.$salt; //把密码和salt连接
$b=md5($b); //执行MD5散列
return $b; //返回散列
}
//二级加密
function chash($c){
$new_salt="gaowenjie123"; 
$str=$c.$new_salt; 
$str=md5(md5(base64_encode($str))); 
return $str;
}
//三级加密
function ahash($c){
$new_salt="gaowenjie123"; 
$str=$c.$new_salt; 
$str=sha1(md5(md5(base64_encode($str)))); 
return $str;
}
function inject_check($sql_str) { //防止注入
$check = preg_match('/select|insert|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile/i', $sql_str);
if ($check) {
	return 202; //疑似恶意代码
} else {
	return $sql_str;
}
}

?>

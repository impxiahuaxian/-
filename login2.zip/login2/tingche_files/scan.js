(function () {
    var tanAll=$(".tanAll");
    var pay=$(".pay");
    function sessionlockid(lockid){
        var strArr = JSON.stringify(lockid);
        sessionStorage.setItem("lockid",strArr);
    }
    function scanmain() {
        scanmodle();
        scanevent();
    }
    function scanmodle() {
        var request={url:"http://dudu2.iot.mk/demo/scan.html"};
        $.ajax({
            type:'POST',
            url:'http://dudu2.iot.mk:9527/v2/scan/power',
            data:JSON.stringify(request),
            dataType: 'json',
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            success:function(response){
                var result=response.result;
//                    alert(result.app_id);
//                    alert(result.timestamp);
//                    alert(result.nonce_str);
//                    alert(result.signature);
                wx.config({
                    debug: false,
                    appId: result.app_id,
                    timestamp:result.timestamp,
                    nonceStr:result.nonce_str,
                    signature:result.signature,
                    jsApiList : [ 'checkJsApi', 'scanQRCode' ]
                });
                wx.error(function(res) {
                    tanAll.css("display","block");
                    pay.click(function () {
                        window.location.href='hand_import.html';
                    })
                });
                wx.ready(function() {
                    wx.checkJsApi({
                        jsApiList : ['scanQRCode'],
                        success : function(res) {
                            console.log(res);
                        }
                    });
                    $(".content_scan").on("click",".wx",function () {
                        wx.scanQRCode({
                            needResult : 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
                            scanType : [ "qrCode"], // 可以指定扫二维码还是一维码，默认二者都有
                            success : function(res) {
                                var result1 = res.resultStr;// 当needResult 为 1 时，扫码返回的结果
                                var lockid=result1.split("=")[1];
                                console.log(lockid);
                                sessionlockid(lockid);
                                window.location.href='hand_import.html';
                            }
                        });
                    });
                });
            }
        });
    }
    function scanevent() {
        $(".hand").on("click",function () {
            window.location.href='hand_import.html';
        });
    }
    scanmain();

})();
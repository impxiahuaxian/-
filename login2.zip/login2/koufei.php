<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<script type="text/javascript" src="../cookie.js"></script>

<title>�۷�</title>
<?php 

 $m = $_COOKIE["name1"];
 $n = $_COOKIE["pwd1"];
 $q = $_COOKIE["money1"];
 //echo ($m);
 //echo ($_POST["chongzhi"]);
if($a = "user1=1")
{
$con = mysql_connect("localhost","root","root");//��������·
$nn = mysql_select_db("test", $con);
$sql1 = mysql_query("SELECT money FROM username WHERE username=$_COOKIE[name1]");
$datarow = mysql_num_rows($sql1); //����
            //ѭ�����������ݱ��е�����
$sql_arr = mysql_fetch_assoc($sql1);
$money = $sql_arr['money'];
$chz = $money - $q;				
$sql=" UPDATE username SET money=$chz WHERE username=$_COOKIE[name1]"; 

if (!mysql_query($sql,$con))
 {
  die('Error: ' . mysql_error());
    
  }
  echo"����ɹ�";
  echo "<script>window.location.href='shouye.html'</script>";
  }
	  
	   
?>
</head>

<body>
</body>
</html>

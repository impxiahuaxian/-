(function () {
    var Util = (function(){
        var StorageGetter = function(key){
            return JSON.parse(localStorage.getItem(key));
        };
        var StorageSetter = function(key,val){
            var strArr = JSON.stringify(val);
            return localStorage.setItem(key,strArr);
        };
        return {
            StorageGetter:StorageGetter,
            StorageSetter:StorageSetter
        }
    })();
    var stop=$(".content_p3 .stop");
    var input = $(".coding input");
    var input_all;
    var inputid;
    var span=$(".hour_number span").eq(0);
    var hour=parseInt(span.text());
    var spanminute=$(".minute_number span").eq(0);
    var minute=parseInt(spanminute.text());
    var tanAll=$(".tanAll");
    var phone=JSON.parse(localStorage.getItem("phone"));
    var lockid =JSON.parse(sessionStorage.getItem("lockid"));
    //console.log(lockid);
    //var lockid=17110019;
    //将数字转化为数组
    function digitize1(n) {
        return (n + "").split("").map(Number);
    }
    if (lockid!==null){
        // input_all=lockid;
        inputid=lockid;

        for (var i = 0; i < input.length; i++) {
            var t = input[i];
            t.index = i;
            var text=digitize1(lockid)[i];
            $(t).val(text);
        }
    }else {

        // for (var i = 0; i < input.length; i++) {
        //     var t = input[i];
        //     t.index = i;
        //     t.setAttribute("readonly", true);
        //     t.onkeyup = function() {
        //         this.value = this.value.replace(/^(.).*$/, '$1');
        //         //console.log(this.value);//客户输入的值
        //         // input_all+=this.value;
        //         var next = this.index + 1;
        //         if (next > input.length - 1) return;
        //         input[next].removeAttribute("readonly");
        //         input[next].focus();
        //     }
        // }
        // input[0].removeAttribute("readonly");
    }
    //钱包金额
   
    if (lockid!==null){
        var request={
            deviceid:lockid
        };
        pricAjax(request);
    }else {
        $('input').on('input propertychange', function() {
            if($.trim($("#input").val()) !=="" ){
                $("#input").blur();
                for (var i = 0; i < input.length; i++) {
                    inputid+=$(input[i]).val();
                }
                inputid=inputid.split("undefined")[1];
                var request={
                    deviceid:inputid
                };
                //input_all=inputid;
                console.log(request);
				console.log(request.deviceid);
                pricAjax(request);
            }
        });
    }

    stop.click(function () {
        if (inputid!==undefined){
          
                Util.StorageSetter("hour",hour);
                Util.StorageSetter("minute",minute);
                var time = hour*60;
                time+=minute;
                var request={
                    id:inputid,
                    time:time,
                    phone:phone
                };
                console.log(request);
				
                scanAjax(request);
          
        }else {
            tanAll.show().delay(2000).fadeOut();
            tanAll.click(function () {
                tanAll.hide();
            });
        }
    });
    function scanAjax(request) {
        $.ajax({
            type:'POST',
            url:'http://dudu2.iot.mk:9527/v2/scan/scan',
            data:JSON.stringify(request),
            dataType: 'json',
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            success: function (response){
                console.log(response);
                if (response.errCode === 1000) {
                    console.log(response.result);
                    tanAll.show();
                    $(".pic1").addClass("pic");
                    $(".text").text("正在为您开锁,锁正常打开后点击确认停上您的爱车");
                    $(".pay").text("确认开锁");
                    var code=1;
                    Util.StorageSetter("key-order",code);
                    tanAll.click(function () {
                        window.location.href='my_orderlist.html';
                    })
                } else if (response.errCode === 49){
                    console.log(response.result);
                    Util.StorageSetter("hand_prestore",response.result);
                    tanAll.show();
                    $(".pic1").addClass("picerr");
                    $(".text").text("您的钱包余额不够，请充值钱包");
                    tanAll.click(function () {
                        window.location.href='prestore.html';
                    })

                }else if (response.errCode === 44){
                    console.log(response.result);
                    tanAll.show();
                    $(".pic1").addClass("picerr");
                    $(".text").text("该车已经被预定，请选择其他车位");
                    tanAll.click(function () {
                        window.location.href='../index.html';
                    })

                } else if (response.errCode === 39){
                    $(".text").text("该车已经是打开状态，请勿重复发送");
                    $(".pic1").addClass("picerr");
                    tanAll.show();
                    tanAll.click(function () {
                        window.location.href='../index.html';
                    })
                }else if (response.errCode === 52){
                    $(".pic1").addClass("picerr");
                    tanAll.show();
                    $(".text").text("该车车主并没有共享，不能扫码开锁");
                    tanAll.click(function () {
                        window.location.href='../index.html';
                    })
                }else if(response.errCode === 53){
                    $(".pic1").addClass("picerr");
                    tanAll.show();
                    $(".text").text("车主您好，请到车位管理开锁");
                    tanAll.click(function () {
                        window.location.href='carport_manage.html';
                    })
                }
                else{
                    $(".pic1").addClass("picerr");
                    $(".text").text(response.result);
                    tanAll.show().delay(3000).fadeOut();
                    tanAll.click(function () {
                        tanAll.hide();
                    });
                    console.log(response.result);
                }
            }
        });
    }

    function pricAjax(request) {
        $.ajax({
            type:'POST',
            url:'http://dudu2.iot.mk:9527/v2/parking/berthinfobyid',
            data:JSON.stringify(request),
            dataType: 'json',
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            success: function (response) {
                if (response.errCode === 1000) {
                    console.log(response.result);
                    var Price=(response.result).Price/100;
                    $(".scan_carportmoney").text("嗨,主人,预定我需要"+Price+"元/小时")
                } else{
                    console.log(response.result);
                    $(".scan_carportmoney").text("正在帮您努力找价格");
                }
            }
        });
    }
})();

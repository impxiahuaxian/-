// JavaScript Document
document.write("<script language=javascript src='./api/api.js'></script>");
 var stop=$(".content_p3 .stop");
    var input = $(".coding input");
	  var inputid;
 $('input').on('input propertychange', function() {
            if($.trim($("#input").val()) !=="" ){
                $("#input").blur();
                for (var i = 0; i < input.length; i++) {
                    inputid+=$(input[i]).val();
                }
                inputid=inputid.split("undefined")[1];
                var request={
                    deviceid:inputid
                };
                //input_all=inputid;
                console.log(request);
				console.log(request.deviceid);
                 console.log(inputid);
            }
        });
      

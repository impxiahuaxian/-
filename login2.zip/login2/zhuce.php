<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
	<meta name="viewport" content="width=device-width, initial-scale=1" />  
    <title>注册</title>  
    <style type="text/css">  
        @import url(http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300);  
        * {  
          box-sizing: border-box;  
          margin: 0;  
          padding: 0;  
          font-weight: 300;  
        }  
        body {  
          font-family: 'Source Sans Pro', sans-serif;  
          color: white;  
          font-weight: 300;  
        }  
        body ::-webkit-input-placeholder {  
          /* WebKit browsers */  
          font-family: 'Source Sans Pro', sans-serif;  
          color: white;  
          font-weight: 300;  
        }  
        body :-moz-placeholder {  
          /* Mozilla Firefox 4 to 18 */  
          font-family: 'Source Sans Pro', sans-serif;  
          color: white;  
          opacity: 1;  
          font-weight: 300;  
        }  
        body ::-moz-placeholder {  
          /* Mozilla Firefox 19+ */  
          font-family: 'Source Sans Pro', sans-serif;  
          color: white;  
          opacity: 1;  
          font-weight: 300;  
        }  
        body :-ms-input-placeholder {  
          /* Internet Explorer 10+ */  
          font-family: 'Source Sans Pro', sans-serif;  
          color: white;  
          font-weight: 300;  
        }  
        .wrapper {  
          background: #50a3a2;  
          background: -webkit-linear-gradient(top left, #50a3a2 0%, #53e3a6 100%);  
          background: linear-gradient(to bottom right, #50a3a2 0%, #53e3a6 100%);  
          position: absolute;  
          left: 0;  
          width: 100%;  
          height: 100%;  
        /*  margin-top: -200px;*/  
          overflow: hidden;  
        }  
        .wrapper.form-success .container h1 {  
          -webkit-transform: translateY(85px);  
                  transform: translateY(85px);  
        }  
        .container {  
          max-width: 600px;  
          margin: 0 auto;  
          padding: 80px 0;  
           padding-top:100px;  
          height: 400px;  
          text-align: center;  
        }  
        .container h1 {  
          font-size: 40px;  
          -webkit-transition-duration: 1s;  
                  transition-duration: 1s;  
          -webkit-transition-timing-function: ease-in-put;  
                  transition-timing-function: ease-in-put;  
          font-weight: 200;  
        }  
        form {  
          padding: 20px 0;  
          position: relative;  
          z-index: 2;  
        }  
        form input {  
          -webkit-appearance: none;  
             -moz-appearance: none;  
                  appearance: none;  
          outline: 0;  
          border: 1px solid rgba(255, 255, 255, 0.4);  
          background-color: rgba(255, 255, 255, 0.2);  
          width: 250px;  
          border-radius: 3px;  
          padding: 10px 15px;  
          margin: 0 auto 10px auto;  
          display: block;  
          text-align: center;  
          font-size: 18px;  
          color: white;  
          -webkit-transition-duration: 0.25s;  
                  transition-duration: 0.25s;  
          font-weight: 300;  
        }  
        form input:hover {  
          background-color: rgba(255, 255, 255, 0.4);  
        }  
        form input:focus {  
          background-color: white;  
          width: 300px;  
          color: #53e3a6;  
        }  
        form button {  
          -webkit-appearance: none;  
             -moz-appearance: none;  
                  appearance: none;  
          outline: 0;  
          background-color: white;  
          border: 0;  
          padding: 10px 15px;  
          color: #53e3a6;  
          border-radius: 3px;  
          width: 125px;  
          cursor: pointer;  
          font-size: 18px;  
          -webkit-transition-duration: 0.25s;  
                  transition-duration: 0.25s;  
        }  
        form button:hover {  
          background-color: #f5f7f9;  
        }  
        .bg-bubbles {  
          position: absolute;  
          top: 0;  
          left: 0;  
          width: 100%;  
          height: 100%;  
          z-index: 1;  
        }  
        .bg-bubbles li {  
          position: absolute;  
          list-style: none;  
          display: block;  
          width: 40px;  
          height: 40px;  
          background-color: rgba(255, 255, 255, 0.15);  
          bottom: -160px;  
          -webkit-animation: square 25s infinite;  
          animation: square 25s infinite;  
          -webkit-transition-timing-function: linear;  
          transition-timing-function: linear;  
        }  
        .bg-bubbles li:nth-child(1) {  
          left: 10%;  
        }  
        .bg-bubbles li:nth-child(2) {  
          left: 20%;  
          width: 80px;  
          height: 80px;  
          -webkit-animation-delay: 2s;  
                  animation-delay: 2s;  
          -webkit-animation-duration: 17s;  
                  animation-duration: 17s;  
        }  
        .bg-bubbles li:nth-child(3) {  
          left: 25%;  
          -webkit-animation-delay: 4s;  
                  animation-delay: 4s;  
        }  
        .bg-bubbles li:nth-child(4) {  
          left: 40%;  
          width: 60px;  
          height: 60px;  
          -webkit-animation-duration: 22s;  
                  animation-duration: 22s;  
          background-color: rgba(255, 255, 255, 0.25);  
        }  
        .bg-bubbles li:nth-child(5) {  
          left: 70%;  
        }  
        .bg-bubbles li:nth-child(6) {  
          left: 80%;  
          width: 120px;  
          height: 120px;  
          -webkit-animation-delay: 3s;  
                  animation-delay: 3s;  
          background-color: rgba(255, 255, 255, 0.2);  
        }  
        .bg-bubbles li:nth-child(7) {  
          left: 32%;  
          width: 160px;  
          height: 160px;  
          -webkit-animation-delay: 7s;  
                  animation-delay: 7s;  
        }  
        .bg-bubbles li:nth-child(8) {  
          left: 55%;  
          width: 20px;  
          height: 20px;  
          -webkit-animation-delay: 15s;  
                  animation-delay: 15s;  
          -webkit-animation-duration: 40s;  
                  animation-duration: 40s;  
        }  
        .bg-bubbles li:nth-child(9) {  
          left: 25%;  
          width: 10px;  
          height: 10px;  
          -webkit-animation-delay: 2s;  
                  animation-delay: 2s;  
          -webkit-animation-duration: 40s;  
                  animation-duration: 40s;  
          background-color: rgba(255, 255, 255, 0.3);  
        }  
        .bg-bubbles li:nth-child(10) {  
          left: 90%;  
          width: 160px;  
          height: 160px;  
          -webkit-animation-delay: 11s;  
                  animation-delay: 11s;  
        }  
        @-webkit-keyframes square {  
          0% {  
            -webkit-transform: translateY(0);  
                    transform: translateY(0);  
          }  
          100% {  
            -webkit-transform: translateY(-700px) rotate(600deg);  
                    transform: translateY(-700px) rotate(600deg);  
          }  
        }  
        @keyframes square {  
          0% {  
            -webkit-transform: translateY(0);  
                    transform: translateY(0);  
          }  
          100% {  
            -webkit-transform: translateY(-700px) rotate(600deg);  
                    transform: translateY(-700px) rotate(600deg);  
          }  
        }  
        .cc{
	text-decoration: none;
	color: #CCCCCC;
        }  
    </style>  
    <script type="text/javascript">  
          
         $("#login-button").click(function(event){  
                 event.preventDefault();  
               
             $('form').fadeOut(500);  
             $('.wrapper').addClass('form-success');  
        });  
        //验证信息填写是否有误  
        function check()  
        {  
           if(form.username.value.length<6 || form.username.value.length>16)  
           {  
           alert('用户名不合法！请输入6-16位用户名');  
           form.username.focus();  
           return false;  
           }  
           if(form.password.value.length<6 ||form.password.value.length>16)  
           {  
           alert('密码不合法！请输入6-16位密码');  
           form.username.focus();  
           return false;  
           }  
           if(form.password.value != form.pass2.value)//判断两次输入的密码是否一致  
           {  
            alert("两次输入的密码不一致！");  
            form.pass2.focus();  
            return false;  
           }  
		   var yan1=document.getElementById("yan").value;
		   var yan2=num;
		   if(yan1!=yan2)
		   {
			   alert("验证码错误!"); 
			//   alert(yan1);
			//  alert(yan2);
            form.username.focus();  
			reCode();
            return false;  
			}
	  if(form.email.value==""){
		 alert("Email不能为空！");
		 return false;
		form.email.focus();
	   }
	  var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	  if(!reg.test(form.email.value)){ 
		alert("Email格式错误！");
		form.email.focus();
		return false;
		
	}
        }  
    </script>
	  
</head>
<body>
 <div class="wrapper">  
        <div class="container">  
            <h1>Welcome</h1>  
              
            <form name='form' class="form" action='zhuce_ok.php' method='post' onSubmit="return check();">  
                <input type="text" placeholder="用户名" name='username'>  
                <input type="password" placeholder="密　码" name='password'>  
                <input type="password" placeholder="确认密码" name='pass2'>
				<input type="text" placeholder="邮箱" name="email">
				<input id="yan" placeholder="验证码">
				 <script language="javascript">  
      var num1=Math.round(Math.random()*10000000);          //生成随机数  
      num=num1.toString().substr(0,4);                  //截取随机数的前4个字符  
      document.write("<img name=codeimg src='yanzhengma.php?num="+num+"'>"); //将截取值传递到图像处理页中  
     // form.yan.value=num;                      //将截取值赋给表单中的隐藏域
      function reCode(){                        //定义方法,重新生成验证码  
           var num1=Math.round(Math.random()*10000000); //生成随机数  
           num=num1.toString().substr(0,4);         //截取随机数  
           document.codeimg.src="yanzhengma.php?num="+num;  ///将截取值传递到图像处理页中
           //form.yan.value=num;            //将截取值赋给表单中的隐藏域           
       }  
    </script>    
				<a href="javascript:reCode()" class="cc">看不清</a> <br>
                 <button type="button" id="login-button" onClick="javascrtpt:window.location.href='index.html'">登&nbsp;&nbsp;&nbsp;录</a></button>  
                <button type="submit" id="register-button" value='Submit' name='Submit' >注&nbsp;&nbsp;&nbsp;册</button>  
            </form>  
        </div>  
          
        <ul class="bg-bubbles">  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
            <li></li>  
        </ul>  
    </div> 
</body>
</html